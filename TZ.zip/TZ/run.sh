#!/bin/bash

g++-7 -g -o prac.out ./Code/tz1.cpp -I ./Headers/ -std=c++17 -Wall -Werror

./prac.out