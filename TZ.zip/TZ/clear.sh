#!/bin/bash

rm *.out

clear 
ls