#!/bin/bash

valgrind ./prac.out
